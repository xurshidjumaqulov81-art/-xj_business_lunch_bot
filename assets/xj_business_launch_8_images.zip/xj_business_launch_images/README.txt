XJ BUSINESS LAUNCH — BOT RASMLARI

Barcha rasmlarni bot loyihasidagi:
assets/
papkasiga joylang.

Fayl nomlarini o'zgartirmang:

1. business_launch.jpg   — Business Launch haqida ma'lumot
2. founder_day.jpg       — Founder Day haqida ma'lumot
3. founder_lunch.jpg     — Founder Lunch haqida ma'lumot
4. conditions.jpg        — Qatnashish shartlari haqida ma'lumot
5. contest.jpg           — Maxsus tanlov haqida ma'lumot
6. contest_apply.jpg     — Maxsus tanlovga qatnashish
7. registration.jpg      — Ro'yxatdan o'tish
8. faq.jpg               — Savol-javob

Eslatma:
Hozirgi bot kodida media.py 1,2,3,4,5,7,8 rasmlarni avtomatik taniydi.
6-rasm (contest_apply.jpg) uchun contest.py ga rasm yuborish qismini qo'shish kerak.